<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8" />
    <title>Lume WiFI</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/1.11.8/semantic.min.css"/>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/1.11.8/semantic.min.js"></script>
<style type="text/css">
body {
    overflow-x:hidden;
}
::-webkit-scrollbar { 
    display: none; 
}
</style>
<html>
<body>
<form class="ui form">
  <div class="field">
    <label>SSID</label>
    <input type="text" name="SSID" placeholder="First Name">
  </div>
  <div class="field">
    <label>Password</label>
    <input type="text" name="Password" placeholder="Last Name">
  </div>
 
  <button class="ui button" type="submit">Submit</button>
</form>
<br>
<a href="settings.php">Settings</a>
</body>
</html>
<script type="text/javascript">

</script>


