<!DOCTYPE HTML>
<html>
<head>
    <meta charset="utf-8" />
    <title>Lume WiFI</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/1.11.8/semantic.min.css"/>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/1.11.8/semantic.min.js"></script>
<style type="text/css">
body {
    overflow-x:hidden;
}
::-webkit-scrollbar { 
    display: none; 
}
</style>
<html>
<body>
Developer Settings
<hr>
<h3>Function Demos</h3>
<a href="http://localhost/lumebot.com/public_html/lindenhurst/inside/middleware/uiRunArduino_amplitude.php">Amplitude
</br>
</br>
<a href="http://localhost/lumebot.com/public_html/lindenhurst/inside/middleware/uiRunArduino_tunerPink_RC1.php">Tuner</a>
</br>
</br>
<h3>System Settings</h3>
<a href="wifiBoot.php">Wifi</a>
</br>
</br>
Update Software
</br>
</br>
<hr>
<a href="index.html">Home</a>
</body>
</html>
<script type="text/javascript">

</script>
