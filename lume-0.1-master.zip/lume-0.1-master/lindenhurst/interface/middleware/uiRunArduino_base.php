<?php
exec('sudo python /path/to/function/dir/sketchRun.py');
header('Location: http://localhost/lumebot.com/public_html/lindenhurst/inside/');
?>
