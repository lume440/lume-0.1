Chromium launch script is in the users LXDE subfolders. For lindenhurst it resides at /home/users/maos/.config/lxsession/LXDE/autostart
