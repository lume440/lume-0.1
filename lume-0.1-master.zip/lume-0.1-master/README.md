# lume-0.1
Lume440 Dev Channel
![Alt text](lindyDirectoryTree.png?raw=true "Directory Tree")
</br>
Current directory structure:

